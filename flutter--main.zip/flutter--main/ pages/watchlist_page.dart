import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/stock_provider.dart';
import '../widgets/stock_list_item.dart';
import '../utils/navigation_helper.dart';
import 'stock_detail_page.dart';

class WatchlistPage extends StatelessWidget {
  const WatchlistPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<StockProvider>(
        builder: (context, stockProvider, _) {
          if (stockProvider.watchlist.isEmpty) {
            return _buildEmptyWatchlist(context);
          }

          return RefreshIndicator(
            onRefresh: () => stockProvider.fetchStocks(),
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: stockProvider.watchlist.length,
              itemBuilder: (context, index) {
                final stock = stockProvider.watchlist[index];
                return Dismissible(
                  key: Key(stock.symbol),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.delete,
                      color: Colors.white,
                      size: 28,
                    ),
                  ),
                  confirmDismiss: (direction) async {
                    return await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: const Text('Remove from Watchlist'),
                          content: Text(
                            'Are you sure you want to remove ${stock.symbol} from your watchlist?',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              child: const Text('Cancel'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(true),
                              child: const Text('Remove'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  onDismissed: (direction) {
                    stockProvider.removeFromWatchlist(stock.symbol);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('${stock.symbol} removed from watchlist'),
                        action: SnackBarAction(
                          label: 'Undo',
                          onPressed: () {
                            stockProvider.addToWatchlist(stock);
                          },
                        ),
                      ),
                    );
                  },
                  child: StockListItem(
                    stock: stock,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => StockDetailPage(symbol: stock.symbol),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyWatchlist(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.star_border,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'Your watchlist is empty',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Add stocks to your watchlist to track them here',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[500],
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              NavigationHelper.goToStocksTab();
            },
            icon: const Icon(Icons.add),
            label: const Text('Browse Stocks'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
          ),
        ],
      ),
    );
  }
}