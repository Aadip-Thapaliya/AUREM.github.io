import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/stock_provider.dart';
import '../providers/news_provider.dart';
import '../widgets/stock_list_item.dart';
import '../widgets/news_card.dart';
import '../utils/navigation_helper.dart';
import 'stock_detail_page.dart';
import 'watchlist_page.dart';
import 'portfolio_page.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    NavigationHelper.selectedTabNotifier.addListener(_onTabChanged);
  }

  @override
  void dispose() {
    NavigationHelper.selectedTabNotifier.removeListener(_onTabChanged);
    super.dispose();
  }

  void _onTabChanged() {
    setState(() {
      _selectedIndex = NavigationHelper.selectedTabNotifier.value;
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('StockWatch'),
        elevation: 0,
        actions: [
          // User Avatar
          if (authProvider.currentUser != null)
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SettingsPage()),
                );
              },
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: CircleAvatar(
                  backgroundImage: authProvider.currentUser!.photoUrl != null
                      ? NetworkImage(authProvider.currentUser!.photoUrl!)
                      : null,
                  child: authProvider.currentUser!.photoUrl == null
                      ? Text(_getInitials(authProvider.currentUser!.displayName ??
                      authProvider.currentUser!.email ?? 'U'))
                      : null,
                ),
              ),
            ),
        ],
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: const [
          _StocksTab(),
          PortfolioPage(),
          _NewsTab(),
          WatchlistPage(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() => _selectedIndex = index);
          NavigationHelper.selectedTabNotifier.value = index;
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.trending_up),
            label: 'Stocks',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_balance_wallet),
            label: 'Portfolio',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.article),
            label: 'News',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            label: 'Watchlist',
          ),
        ],
      ),
    );
  }

  String _getInitials(String name) {
    if (name.isEmpty) return 'U';
    List<String> nameParts = name.split(' ');
    if (nameParts.length >= 2) {
      return '${nameParts[0][0]}${nameParts[1][0]}'.toUpperCase();
    }
    return name[0].toUpperCase();
  }
}

class _StocksTab extends StatelessWidget {
  const _StocksTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<StockProvider>(
      builder: (context, stockProvider, _) {
        if (stockProvider.isLoading && stockProvider.stocks.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        if (stockProvider.error != null) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline, size: 64, color: Colors.red),
                const SizedBox(height: 16),
                Text('Error: ${stockProvider.error}'),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => stockProvider.fetchStocks(),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: () => stockProvider.fetchStocks(),
          child: ListView.builder(
            itemCount: stockProvider.stocks.length,
            itemBuilder: (context, index) {
              final stock = stockProvider.stocks[index];
              return StockListItem(
                stock: stock,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StockDetailPage(symbol: stock.symbol),
                    ),
                  );
                },
              );
            },
          ),
        );
      },
    );
  }
}

class _NewsTab extends StatelessWidget {
  const _NewsTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<NewsProvider>(
      builder: (context, newsProvider, _) {
        if (newsProvider.isLoading && newsProvider.marketNews.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        if (newsProvider.error != null) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline, size: 64, color: Colors.red),
                const SizedBox(height: 16),
                Text('Error: ${newsProvider.error}'),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => newsProvider.fetchMarketNews(),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: () => newsProvider.fetchMarketNews(),
          child: ListView.builder(
            itemCount: newsProvider.marketNews.length,
            itemBuilder: (context, index) {
              return NewsCard(article: newsProvider.marketNews[index]);
            },
          ),
        );
      },
    );
  }
}