import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/stock_provider.dart';
import '../providers/portfolio_provider.dart';
import '../widgets/buy_sell_dialog.dart';

class StockDetailPage extends StatefulWidget {
  final String symbol;

  const StockDetailPage({
    Key? key,
    required this.symbol,
  }) : super(key: key);

  @override
  State<StockDetailPage> createState() => _StockDetailPageState();
}

class _StockDetailPageState extends State<StockDetailPage> {
  @override
  Widget build(BuildContext context) {
    return Consumer2<StockProvider, PortfolioProvider>(
      builder: (context, stockProvider, portfolioProvider, _) {
        final stock = stockProvider.getStockBySymbol(widget.symbol);
        final holding = portfolioProvider.getHolding(widget.symbol);
        final isInWatchlist = stockProvider.isInWatchlist(widget.symbol);

        if (stock == null) {
          return Scaffold(
            appBar: AppBar(title: Text(widget.symbol)),
            body: const Center(
              child: Text('Stock not found'),
            ),
          );
        }

        final isPositive = stock.change >= 0;

        return Scaffold(
          appBar: AppBar(
            title: Text(stock.symbol),
            actions: [
              IconButton(
                onPressed: () => _toggleWatchlist(stockProvider, isInWatchlist),
                icon: Icon(
                  isInWatchlist ? Icons.star : Icons.star_border,
                  color: isInWatchlist ? Colors.amber : null,
                ),
              ),
            ],
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Stock Price Card
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          stock.name,
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '\$${stock.currentPrice.toStringAsFixed(2)}',
                          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Icon(
                              isPositive ? Icons.trending_up : Icons.trending_down,
                              color: isPositive ? Colors.green : Colors.red,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${isPositive ? '+' : ''}\$${stock.change.toStringAsFixed(2)} (${stock.changePercent.toStringAsFixed(2)}%)',
                              style: TextStyle(
                                color: isPositive ? Colors.green : Colors.red,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Portfolio Position (if owned)
                if (holding != null) ...[
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Your Position',
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          const SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Shares Owned:'),
                              Text(
                                '${holding.shares}',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Average Price:'),
                              Text(
                                '\$${holding.averagePrice.toStringAsFixed(2)}',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Current Value:'),
                              Text(
                                '\$${holding.currentValue.toStringAsFixed(2)}',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Total Gain/Loss:'),
                              Text(
                                '${holding.totalGainLoss >= 0 ? '+' : ''}\$${holding.totalGainLoss.toStringAsFixed(2)}',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: holding.totalGainLoss >= 0 ? Colors.green : Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                // Stock Info
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Stock Information',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 12),
                        _buildInfoRow('Symbol', stock.symbol),
                        _buildInfoRow('Volume', '${stock.volume.toString().replaceAllMapped(
                          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
                              (Match m) => '${m[1]},',
                        )}'),
                        _buildInfoRow('Market Cap', '\$${(stock.marketCap / 1000000000).toStringAsFixed(2)}B'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 100), // Space for floating buttons
              ],
            ),
          ),
          floatingActionButton: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (holding != null) ...[
                FloatingActionButton.extended(
                  onPressed: () => _showSellDialog(context, stock),
                  backgroundColor: Colors.red,
                  icon: const Icon(Icons.trending_down),
                  label: const Text('Sell'),
                  heroTag: 'sell',
                ),
                const SizedBox(height: 12),
              ],
              FloatingActionButton.extended(
                onPressed: () => _showBuyDialog(context, stock),
                backgroundColor: Colors.green,
                icon: const Icon(Icons.trending_up),
                label: const Text('Buy'),
                heroTag: 'buy',
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  void _showBuyDialog(BuildContext context, stock) {
    showDialog(
      context: context,
      builder: (context) => BuySellDialog(
        stock: stock,
        isBuying: true,
      ),
    );
  }

  void _showSellDialog(BuildContext context, stock) {
    showDialog(
      context: context,
      builder: (context) => BuySellDialog(
        stock: stock,
        isBuying: false,
      ),
    );
  }

  void _toggleWatchlist(StockProvider stockProvider, bool isInWatchlist) {
    final stock = stockProvider.getStockBySymbol(widget.symbol);
    if (stock == null) return;

    if (isInWatchlist) {
      stockProvider.removeFromWatchlist(widget.symbol);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${widget.symbol} removed from watchlist'),
        ),
      );
    } else {
      stockProvider.addToWatchlist(stock);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${widget.symbol} added to watchlist'),
        ),
      );
    }
  }
}