import 'package:flutter/material.dart';
import '../models/news_article.dart';

class NewsCard extends StatelessWidget {
  final NewsArticle article;

  const NewsCard({
    Key? key,
    required this.article,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 3,
      child: InkWell(
        onTap: () => _showArticleDialog(context),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      article.source,
                      style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _formatTime(article.publishedAt),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                article.title,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  height: 1.4,
                  color: Theme.of(context).textTheme.titleLarge?.color,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 12),
              Text(
                article.summary,
                style: TextStyle(
                  fontSize: 15,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                  height: 1.5,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.trending_up,
                          color: Colors.green,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Market News',
                          style: TextStyle(
                            color: Colors.green,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: () => _showArticleDialog(context),
                    icon: const Icon(Icons.article, size: 16),
                    label: const Text('Read Full Article'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      textStyle: const TextStyle(fontSize: 14),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }

  void _showArticleDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Container(
          width: MediaQuery.of(context).size.width * 0.8,
          height: MediaQuery.of(context).size.height * 0.8,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Theme.of(context).dialogBackgroundColor,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          article.source,
                          style: TextStyle(
                            color: Theme.of(context).primaryColor,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _formatTime(article.publishedAt),
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                    iconSize: 28,
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Title
              Text(
                article.title,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  height: 1.3,
                  color: Theme.of(context).textTheme.headlineLarge?.color,
                ),
              ),
              const SizedBox(height: 20),

              // Content - Scrollable
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Summary
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          article.summary,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                            height: 1.5,
                            color: Theme.of(context).textTheme.bodyLarge?.color,
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Full Article Content
                      Text(
                        'Full Article:',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      const SizedBox(height: 12),

                      Text(
                        _getFullArticleContent(),
                        style: TextStyle(
                          fontSize: 16,
                          height: 1.6,
                          letterSpacing: 0.2,
                          color: Theme.of(context).textTheme.bodyMedium?.color,
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Market Impact Section
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.grey[800]
                              : Colors.grey[100],
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.trending_up,
                                  color: Theme.of(context).primaryColor,
                                  size: 20,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  'Market Impact',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              _getMarketImpact(),
                              style: TextStyle(
                                fontSize: 16,
                                height: 1.5,
                                color: Theme.of(context).textTheme.bodyMedium?.color,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),

              // Bottom Actions
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text(
                      'Close',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getFullArticleContent() {
    // Generate mock article content based on the title
    if (article.title.toLowerCase().contains('tech') || article.title.toLowerCase().contains('ai') || article.title.toLowerCase().contains('nvidia') || article.title.toLowerCase().contains('apple')) {
      return 'Technology stocks have shown remarkable resilience in today\'s volatile market environment. Major tech companies reported strong quarterly earnings, driven by robust demand for cloud services and artificial intelligence solutions. \n\nThe semiconductor industry, in particular, has benefited from increased demand for chips across various industries including automotive, healthcare, and consumer electronics. Companies like NVIDIA and Apple continue to lead innovation in AI processing and consumer technology.\n\nAnalysts predict continued growth in the tech sector as companies increasingly adopt digital transformation initiatives. The integration of AI into everyday business operations is expected to drive significant revenue growth over the next several quarters.\n\nInvestors are particularly bullish on companies that have established strong positions in AI development and cloud infrastructure. The market capitalization of leading tech firms has grown substantially, reflecting investor confidence in long-term growth prospects.';
    } else if (article.title.toLowerCase().contains('federal') || article.title.toLowerCase().contains('interest') || article.title.toLowerCase().contains('fed')) {
      return 'The Federal Reserve has maintained its current interest rate policy, citing ongoing economic stability and controlled inflation levels. Federal Reserve Chairman Jerome Powell stated that the central bank will continue to monitor economic indicators closely.\n\nThe decision was largely expected by market analysts, who anticipate a measured approach to monetary policy in the coming months. This stance is expected to support continued economic growth while managing inflation expectations.\n\nKey economic indicators show mixed signals, with employment remaining strong while inflation shows signs of moderation. The Fed\'s dual mandate of price stability and full employment continues to guide policy decisions.\n\nMarket participants are closely watching for signals about future rate changes, particularly as economic data continues to evolve. The central bank\'s communication strategy emphasizes data-dependent decision-making and gradual policy adjustments.';
    } else if (article.title.toLowerCase().contains('oil') || article.title.toLowerCase().contains('energy')) {
      return 'Energy markets experienced significant volatility as global supply and demand dynamics continue to shift. Oil prices have been influenced by geopolitical tensions, production decisions by major oil-producing nations, and changing consumption patterns worldwide.\n\nThe transition to renewable energy sources is creating both challenges and opportunities for traditional energy companies. Many firms are investing heavily in clean energy technologies while maintaining their core oil and gas operations.\n\nSupply chain disruptions and infrastructure challenges have added complexity to energy markets. Companies are adapting their strategies to navigate this evolving landscape while meeting growing global energy demands.\n\nInvestors are closely monitoring energy sector developments, particularly as governments worldwide implement policies related to climate change and energy security.';
    } else {
      return 'Market participants are closely watching global economic developments as they navigate an increasingly complex financial landscape. Economic indicators suggest a mixed outlook, with some sectors showing strong performance while others face headwinds.\n\nCorporate earnings reports continue to be a key driver of market sentiment, with investors focusing on companies that demonstrate resilience and adaptability in the current environment. Management guidance and forward-looking statements are receiving heightened scrutiny.\n\nGeopolitical factors are also playing an important role in market dynamics, with investors monitoring international developments that could impact global trade and economic growth.\n\nAnalysts recommend that investors maintain diversified portfolios and consider long-term investment strategies. The current market environment presents both opportunities and challenges for different asset classes, requiring careful analysis and risk management.';
    }
  }

  String _getMarketImpact() {
    if (article.title.toLowerCase().contains('tech') || article.title.toLowerCase().contains('ai')) {
      return 'This development is expected to positively impact tech sector valuations, with particular strength in AI-focused companies. Recommended stocks: NVDA, AAPL, GOOGL, MSFT.';
    } else if (article.title.toLowerCase().contains('federal') || article.title.toLowerCase().contains('fed')) {
      return 'Interest rate decisions typically affect all market sectors. Banks may benefit from stable rates, while growth stocks could see increased investor interest.';
    } else if (article.title.toLowerCase().contains('oil') || article.title.toLowerCase().contains('energy')) {
      return 'Energy sector volatility may create trading opportunities. Consider energy ETFs or individual companies like BP, SHEL for potential exposure.';
    } else {
      return 'Broader market implications suggest maintaining a balanced portfolio approach. Monitor earnings reports and economic indicators for investment guidance.';
    }
  }
}