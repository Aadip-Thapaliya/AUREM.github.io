import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models/stock.dart';
import '../providers/portfolio_provider.dart';

class BuySellDialog extends StatefulWidget {
  final Stock stock;
  final bool isBuying;

  const BuySellDialog({
    Key? key,
    required this.stock,
    required this.isBuying,
  }) : super(key: key);

  @override
  State<BuySellDialog> createState() => _BuySellDialogState();
}

class _BuySellDialogState extends State<BuySellDialog> {
  final TextEditingController _sharesController = TextEditingController(text: '1');
  int get shares => int.tryParse(_sharesController.text) ?? 0;
  double get totalAmount => shares * widget.stock.currentPrice;

  @override
  void dispose() {
    _sharesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<PortfolioProvider>(
      builder: (context, portfolioProvider, _) {
        final holding = portfolioProvider.getHolding(widget.stock.symbol);
        final maxSellShares = holding?.shares ?? 0;

        return AlertDialog(
          title: Text('${widget.isBuying ? 'Buy' : 'Sell'} ${widget.stock.symbol}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Stock info
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.stock.name,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Current Price: \$${widget.stock.currentPrice.toStringAsFixed(2)}',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Shares input
              TextField(
                controller: _sharesController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: InputDecoration(
                  labelText: 'Number of shares',
                  border: const OutlineInputBorder(),
                  suffixText: widget.isBuying
                      ? null
                      : 'Max: $maxSellShares',
                ),
                onChanged: (value) => setState(() {}),
              ),
              const SizedBox(height: 16),

              // Total amount
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Total Amount:',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      '\$${totalAmount.toStringAsFixed(2)}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: widget.isBuying ? Colors.red : Colors.green,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),

              // Available cash or shares
              if (widget.isBuying)
                Text(
                  'Available cash: \$${portfolioProvider.cash.toStringAsFixed(2)}',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                )
              else if (holding != null)
                Text(
                  'You own ${holding.shares} shares (Avg: \$${holding.averagePrice.toStringAsFixed(2)})',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),

              // Error message
              if (portfolioProvider.error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    portfolioProvider.error!,
                    style: const TextStyle(
                      color: Colors.red,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: _canExecuteTrade(portfolioProvider, maxSellShares)
                  ? () => _executeTrade(context, portfolioProvider)
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: widget.isBuying ? Colors.green : Colors.red,
                foregroundColor: Colors.white,
              ),
              child: portfolioProvider.isLoading
                  ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
                  : Text(widget.isBuying ? 'Buy' : 'Sell'),
            ),
          ],
        );
      },
    );
  }

  bool _canExecuteTrade(PortfolioProvider portfolioProvider, int maxSellShares) {
    if (portfolioProvider.isLoading || shares <= 0) return false;

    if (widget.isBuying) {
      return totalAmount <= portfolioProvider.cash;
    } else {
      return shares <= maxSellShares;
    }
  }

  Future<void> _executeTrade(BuildContext context, PortfolioProvider portfolioProvider) async {
    portfolioProvider.clearError();

    bool success;
    if (widget.isBuying) {
      success = await portfolioProvider.buyStock(widget.stock, shares);
    } else {
      success = await portfolioProvider.sellStock(
        widget.stock.symbol,
        shares,
        widget.stock.currentPrice,
      );
    }

    if (success && context.mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${widget.isBuying ? 'Bought' : 'Sold'} $shares shares of ${widget.stock.symbol}',
          ),
          backgroundColor: Colors.green,
        ),
      );
    }
  }
}