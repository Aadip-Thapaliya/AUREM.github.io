import 'package:flutter/material.dart';

class NavigationHelper {
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
  static ValueNotifier<int> selectedTabNotifier = ValueNotifier<int>(0);

  static void goToTab(int index) {
    selectedTabNotifier.value = index;
  }

  static void goToStocksTab() {
    goToTab(0);
  }

  static void goToPortfolioTab() {
    goToTab(1);
  }

  static void goToNewsTab() {
    goToTab(2);
  }

  static void goToWatchlistTab() {
    goToTab(3);
  }
}