import 'package:flutter/foundation.dart';
import '../models/news_article.dart';
import '../services/api_service.dart';

class NewsProvider with ChangeNotifier {
  List<NewsArticle> _marketNews = [];
  bool _isLoading = false;
  String? _error;

  List<NewsArticle> get marketNews => _marketNews;
  bool get isLoading => _isLoading;
  String? get error => _error;

  NewsProvider() {
    fetchMarketNews();
  }

  Future<void> fetchMarketNews() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Use real API service which has fallback to enhanced mock data
      _marketNews = await ApiService.fetchMarketNews();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}