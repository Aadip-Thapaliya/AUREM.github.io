import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AuthProvider with ChangeNotifier {
  UserModel? _currentUser;
  bool _isLoading = false;
  String? _error;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _currentUser != null;

  AuthProvider() {
    _initializeAuthListener();
  }

  void _initializeAuthListener() {
    // Listen to auth state changes when Firebase is configured
    AuthService.authStateChanges.listen((UserModel? user) {
      _currentUser = user;
      notifyListeners();
    });
  }

  Future<bool> signInWithGoogle() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final UserModel? user = await AuthService.signInWithGoogle();
      if (user != null) {
        _currentUser = user;
        return true;
      } else {
        _error = 'Sign in was cancelled or failed';
        return false;
      }
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    _isLoading = true;
    notifyListeners();

    try {
      final bool success = await AuthService.signOut();
      if (success) {
        _currentUser = null;
        _error = null;
      } else {
        _error = 'Failed to sign out';
      }
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}