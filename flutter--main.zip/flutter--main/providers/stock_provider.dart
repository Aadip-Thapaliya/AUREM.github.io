﻿import 'package:flutter/foundation.dart';
import 'dart:math';
import '../models/stock.dart';
import '../services/api_service.dart';

class StockProvider with ChangeNotifier {
  List<Stock> _stocks = [];
  List<Stock> _watchlist = [];
  bool _isLoading = false;
  String? _error;

  List<Stock> get stocks => _stocks;
  List<Stock> get watchlist => _watchlist;
  bool get isLoading => _isLoading;
  String? get error => _error;

  StockProvider() {
    fetchStocks();
    startPriceUpdates(); // Start real-time updates
  }

  Future<void> fetchStocks() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Use real API service which has fallback to enhanced mock data
      _stocks = await ApiService.fetchStocks();
    } catch (e) {
      _error = e.toString();
      // Fallback to local mock data if API service fails
      _stocks = _generateMockStocks();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  List<Stock> _generateMockStocks() {
    final Random random = Random();

    final List<Map<String, dynamic>> stockData = [
      // US Stocks
      {'symbol': 'AAPL', 'name': 'Apple Inc', 'basePrice': 200.0},
      {'symbol': 'GOOGL', 'name': 'Alphabet Inc', 'basePrice': 170.0},
      {'symbol': 'MSFT', 'name': 'Microsoft Corp', 'basePrice': 490.0},
      {'symbol': 'AMZN', 'name': 'Amazon.com Inc', 'basePrice': 211.0},
      {'symbol': 'TSLA', 'name': 'Tesla Inc', 'basePrice': 325.0},
      {'symbol': 'META', 'name': 'Meta Platforms Inc', 'basePrice': 520.0},
      {'symbol': 'NVDA', 'name': 'NVIDIA Corp', 'basePrice': 875.0},
      {'symbol': 'NFLX', 'name': 'Netflix Inc', 'basePrice': 485.0},
      {'symbol': 'ADBE', 'name': 'Adobe Inc', 'basePrice': 650.0},
      {'symbol': 'CRM', 'name': 'Salesforce Inc', 'basePrice': 280.0},
      {'symbol': 'ORCL', 'name': 'Oracle Corp', 'basePrice': 110.0},
      {'symbol': 'INTC', 'name': 'Intel Corp', 'basePrice': 25.0},
      {'symbol': 'AMD', 'name': 'Advanced Micro Devices', 'basePrice': 145.0},
      {'symbol': 'PYPL', 'name': 'PayPal Holdings Inc', 'basePrice': 75.0},
      {'symbol': 'UBER', 'name': 'Uber Technologies Inc', 'basePrice': 68.0},

      // German Stocks (DAX)
      {'symbol': 'SAP.DE', 'name': 'SAP SE', 'basePrice': 125.50},
      {'symbol': 'BMW.DE', 'name': 'Bayerische Motoren Werke AG', 'basePrice': 88.20},
      {'symbol': 'VOW3.DE', 'name': 'Volkswagen AG', 'basePrice': 115.85},
      {'symbol': 'BAS.DE', 'name': 'BASF SE', 'basePrice': 45.75},
      {'symbol': 'SIE.DE', 'name': 'Siemens AG', 'basePrice': 168.90},
      {'symbol': 'ALV.DE', 'name': 'Allianz SE', 'basePrice': 245.60},
      {'symbol': 'DTE.DE', 'name': 'Deutsche Telekom AG', 'basePrice': 23.85},
      {'symbol': 'BEI.DE', 'name': 'Beiersdorf AG', 'basePrice': 135.20},
      {'symbol': 'ADS.DE', 'name': 'Adidas AG', 'basePrice': 165.40},
      {'symbol': 'DBK.DE', 'name': 'Deutsche Bank AG', 'basePrice': 12.95},
      {'symbol': 'DB1.DE', 'name': 'Deutsche Börse AG', 'basePrice': 185.30},
      {'symbol': 'FRE.DE', 'name': 'Fresenius SE & Co. KGaA', 'basePrice': 28.45},
      {'symbol': 'HEN3.DE', 'name': 'Henkel AG & Co. KGaA', 'basePrice': 78.65},
      {'symbol': 'IFX.DE', 'name': 'Infineon Technologies AG', 'basePrice': 32.20},
      {'symbol': 'LIN.DE', 'name': 'Linde plc', 'basePrice': 385.40},
      {'symbol': 'MRK.DE', 'name': 'Merck KGaA', 'basePrice': 165.85},
      {'symbol': 'MUV2.DE', 'name': 'Munich Re', 'basePrice': 445.80},
      {'symbol': 'RWE.DE', 'name': 'RWE AG', 'basePrice': 38.75},
      {'symbol': 'SAR.DE', 'name': 'Sartorius AG', 'basePrice': 245.20},
      {'symbol': 'ZAL.DE', 'name': 'Zalando SE', 'basePrice': 22.85},

      // More Popular Stocks
      {'symbol': 'SPOT', 'name': 'Spotify Technology SA', 'basePrice': 320.0},
      {'symbol': 'SHOP', 'name': 'Shopify Inc', 'basePrice': 95.0},
      {'symbol': 'ZOOM', 'name': 'Zoom Video Communications', 'basePrice': 85.0},
      {'symbol': 'SQ', 'name': 'Block Inc', 'basePrice': 88.0},
      {'symbol': 'COIN', 'name': 'Coinbase Global Inc', 'basePrice': 195.0},
    ];

    return stockData.map((data) {
      final basePrice = data['basePrice'] as double;
      final changePercent = (random.nextDouble() - 0.5) * 10; // -5% to +5%
      final currentPrice = basePrice * (1 + changePercent / 100);
      final change = currentPrice - basePrice;

      return Stock(
        symbol: data['symbol'],
        name: data['name'],
        currentPrice: double.parse(currentPrice.toStringAsFixed(2)),
        change: double.parse(change.toStringAsFixed(2)),
        changePercent: double.parse(changePercent.toStringAsFixed(2)),
        volume: random.nextInt(50000000) + 1000000,
        marketCap: (currentPrice * (random.nextInt(10000) + 1000) * 1000000).toInt(),
      );
    }).toList();
  }

  void addToWatchlist(Stock stock) {
    if (!_watchlist.any((s) => s.symbol == stock.symbol)) {
      _watchlist.add(stock);
      notifyListeners();
    }
  }

  void removeFromWatchlist(String symbol) {
    _watchlist.removeWhere((stock) => stock.symbol == symbol);
    notifyListeners();
  }

  bool isInWatchlist(String symbol) {
    return _watchlist.any((stock) => stock.symbol == symbol);
  }

  Stock? getStockBySymbol(String symbol) {
    try {
      return _stocks.firstWhere((stock) => stock.symbol == symbol);
    } catch (e) {
      return null;
    }
  }

  // Simulate real-time price updates
  void startPriceUpdates() {
    // Update prices every 30 seconds
    Future.delayed(const Duration(seconds: 30), () {
      if (_stocks.isNotEmpty) {
        _updatePrices();
        startPriceUpdates(); // Continue updating
      }
    });
  }

  void _updatePrices() {
    final Random random = Random();

    for (int i = 0; i < _stocks.length; i++) {
      final stock = _stocks[i];
      final priceChange = (random.nextDouble() - 0.5) * 2; // Small price movement
      final newPrice = stock.currentPrice + priceChange;

      if (newPrice > 0) {
        final totalChange = newPrice - (stock.currentPrice - stock.change);
        final totalChangePercent = (totalChange / (stock.currentPrice - stock.change)) * 100;

        _stocks[i] = Stock(
          symbol: stock.symbol,
          name: stock.name,
          currentPrice: double.parse(newPrice.toStringAsFixed(2)),
          change: double.parse(totalChange.toStringAsFixed(2)),
          changePercent: double.parse(totalChangePercent.toStringAsFixed(2)),
          volume: stock.volume,
          marketCap: stock.marketCap,
        );
      }
    }

    // Update watchlist prices
    for (int i = 0; i < _watchlist.length; i++) {
      final watchlistStock = _watchlist[i];
      final updatedStock = _stocks.firstWhere(
            (s) => s.symbol == watchlistStock.symbol,
        orElse: () => watchlistStock,
      );
      _watchlist[i] = updatedStock;
    }

    notifyListeners();
  }
}