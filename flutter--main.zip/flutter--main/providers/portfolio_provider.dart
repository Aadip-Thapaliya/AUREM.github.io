import 'package:flutter/foundation.dart';
import '../models/stock.dart';
import '../models/portfolio_holding.dart';

class PortfolioProvider with ChangeNotifier {
  List<PortfolioHolding> _holdings = [];
  double _cash = 100000.0; // Start with $100,000
  bool _isLoading = false;
  String? _error;

  List<PortfolioHolding> get holdings => _holdings;
  double get cash => _cash;
  bool get isLoading => _isLoading;
  String? get error => _error;

  double get totalValue {
    double stocksValue = _holdings.fold(0.0, (sum, holding) =>
    sum + (holding.currentPrice * holding.shares));
    return stocksValue + _cash;
  }

  double get totalGainLoss {
    return _holdings.fold(0.0, (sum, holding) =>
    sum + holding.totalGainLoss);
  }

  double get totalGainLossPercent {
    double totalCost = _holdings.fold(0.0, (sum, holding) =>
    sum + holding.totalCost);
    if (totalCost == 0) return 0.0;
    return (totalGainLoss / totalCost) * 100;
  }

  Future<bool> buyStock(Stock stock, int shares) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final totalCost = stock.currentPrice * shares;

      if (totalCost > _cash) {
        _error = 'Insufficient funds. You need \$${totalCost.toStringAsFixed(2)} but only have \$${_cash.toStringAsFixed(2)}';
        return false;
      }

      await Future.delayed(const Duration(milliseconds: 500)); // Simulate transaction

      // Check if we already own this stock
      final existingHoldingIndex = _holdings.indexWhere(
              (holding) => holding.symbol == stock.symbol
      );

      if (existingHoldingIndex != -1) {
        // Add to existing holding
        final existingHolding = _holdings[existingHoldingIndex];
        final newTotalShares = existingHolding.shares + shares;
        final newTotalCost = existingHolding.totalCost + totalCost;
        final newAveragePrice = newTotalCost / newTotalShares;

        _holdings[existingHoldingIndex] = PortfolioHolding(
          symbol: stock.symbol,
          name: stock.name,
          shares: newTotalShares,
          averagePrice: newAveragePrice,
          currentPrice: stock.currentPrice,
        );
      } else {
        // Create new holding
        _holdings.add(PortfolioHolding(
          symbol: stock.symbol,
          name: stock.name,
          shares: shares,
          averagePrice: stock.currentPrice,
          currentPrice: stock.currentPrice,
        ));
      }

      _cash -= totalCost;
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> sellStock(String symbol, int shares, double currentPrice) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final holdingIndex = _holdings.indexWhere(
              (holding) => holding.symbol == symbol
      );

      if (holdingIndex == -1) {
        _error = 'You don\'t own any shares of $symbol';
        return false;
      }

      final holding = _holdings[holdingIndex];
      if (shares > holding.shares) {
        _error = 'You only own ${holding.shares} shares of $symbol';
        return false;
      }

      await Future.delayed(const Duration(milliseconds: 500)); // Simulate transaction

      final saleAmount = currentPrice * shares;
      _cash += saleAmount;

      if (shares == holding.shares) {
        // Sell all shares - remove holding
        _holdings.removeAt(holdingIndex);
      } else {
        // Partial sale - update holding
        final newShares = holding.shares - shares;
        final newTotalCost = holding.averagePrice * newShares;

        _holdings[holdingIndex] = PortfolioHolding(
          symbol: holding.symbol,
          name: holding.name,
          shares: newShares,
          averagePrice: holding.averagePrice,
          currentPrice: currentPrice,
        );
      }

      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void updateHoldingPrices(List<Stock> stocks) {
    for (int i = 0; i < _holdings.length; i++) {
      final holding = _holdings[i];
      final stock = stocks.firstWhere(
            (s) => s.symbol == holding.symbol,
        orElse: () => Stock(
          symbol: holding.symbol,
          name: holding.name,
          currentPrice: holding.currentPrice,
          change: 0,
          changePercent: 0,
          volume: 0,
          marketCap: 0,
        ),
      );

      _holdings[i] = PortfolioHolding(
        symbol: holding.symbol,
        name: holding.name,
        shares: holding.shares,
        averagePrice: holding.averagePrice,
        currentPrice: stock.currentPrice,
      );
    }
    notifyListeners();
  }

  PortfolioHolding? getHolding(String symbol) {
    try {
      return _holdings.firstWhere((holding) => holding.symbol == symbol);
    } catch (e) {
      return null;
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}