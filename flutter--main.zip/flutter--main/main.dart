﻿import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'dart:io';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'providers/stock_provider.dart';
import 'providers/news_provider.dart';
import 'providers/portfolio_provider.dart';
import 'providers/theme_provider.dart';
import 'utils/navigation_helper.dart';
import 'splash_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Only initialize Firebase on mobile platforms when configured
  if (!kIsWeb && (Platform.isAndroid || Platform.isIOS)) {
    // TODO: Initialize Firebase when configured
    // await Firebase.initializeApp(
    //   options: DefaultFirebaseOptions.currentPlatform,
    // );
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => StockProvider()),
        ChangeNotifierProvider(create: (_) => NewsProvider()),
        ChangeNotifierProvider(create: (_) => PortfolioProvider()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) {
          return MaterialApp(
            title: 'StockWatch',
            debugShowCheckedModeBanner: false,
            theme: themeProvider.theme,
            navigatorKey: NavigationHelper.navigatorKey,
            home: const SplashPage(),
          );
        },
      ),
    );
  }
}