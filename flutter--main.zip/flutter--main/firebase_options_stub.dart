// Stub file for platforms that don't support Firebase
class DefaultFirebaseOptions {
  static get currentPlatform => null;
}