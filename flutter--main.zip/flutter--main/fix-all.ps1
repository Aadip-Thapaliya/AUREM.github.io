# Script to find all dart files and move them to correct locations

Write-Host "🔍 Finding all Dart files in your project..." -ForegroundColor Cyan

# Find all .dart files
$allDartFiles = Get-ChildItem -Path . -Filter *.dart -Recurse | Where-Object { $_.FullName -notlike "*\build\*" -and $_.FullName -notlike "*\.dart_tool\*" }

Write-Host "`nFound Dart files:" -ForegroundColor Yellow
$allDartFiles | ForEach-Object { Write-Host $_.FullName.Replace((Get-Location).Path + "\", "") }

# Create all necessary directories
Write-Host "`n📁 Creating directory structure..." -ForegroundColor Green
$dirs = @("lib", "lib\models", "lib\services", "lib\providers", "lib\widgets", "lib\pages", "assets")
foreach ($dir in $dirs) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
}

# Define where each file should go
$fileMap = @{
    "splash_page.dart" = "lib\pages\"
    "login_page.dart" = "lib\pages\"
    "home_page.dart" = "lib\pages\"
    "stock_detail_page.dart" = "lib\pages\"
    "watchlist_page.dart" = "lib\pages\"
    "settings_page.dart" = "lib\pages\"
    "stock.dart" = "lib\models\"
    "stock.g.dart" = "lib\models\"
    "news_article.dart" = "lib\models\"
    "news_article.g.dart" = "lib\models\"
    "user.dart" = "lib\models\"
    "api_service.dart" = "lib\services\"
    "auth_service.dart" = "lib\services\"
    "auth_provider.dart" = "lib\providers\"
    "news_provider.dart" = "lib\providers\"
    "stock_list_item.dart" = "lib\widgets\"
    "news_card.dart" = "lib\widgets\"
    "chart_widget.dart" = "lib\widgets\"
}

# Move files to correct locations
Write-Host "`n📂 Moving files to correct locations..." -ForegroundColor Green
foreach ($fileName in $fileMap.Keys) {
    $targetPath = $fileMap[$fileName]

    # Find the file anywhere in the project
    $foundFile = $allDartFiles | Where-Object { $_.Name -eq $fileName } | Select-Object -First 1

    if ($foundFile) {
        $destination = Join-Path $targetPath $fileName
        if ($foundFile.FullName -ne (Resolve-Path $destination -ErrorAction SilentlyContinue)) {
            Copy-Item -Path $foundFile.FullName -Destination $destination -Force
            Write-Host "✓ Moved $fileName to $targetPath" -ForegroundColor Green
        } else {
            Write-Host "✓ $fileName already in correct location" -ForegroundColor Yellow
        }
    } else {
        Write-Host "✗ $fileName NOT FOUND!" -ForegroundColor Red

        # Create a basic version if it's splash_page.dart
        if ($fileName -eq "splash_page.dart") {
            Write-Host "  Creating basic splash_page.dart..." -ForegroundColor Yellow
            $splashContent = @'
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'login_page.dart';
import 'home_page.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({Key? key}) : super(key: key);

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
  }

  Future<void> _checkAuthStatus() async {
    await Future.delayed(const Duration(seconds: 2));

    if (mounted) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => authProvider.isAuthenticated
              ? const HomePage()
              : const LoginPage(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).primaryColor,
              Theme.of(context).primaryColor.withOpacity(0.7),
            ],
          ),
        ),
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.show_chart,
                size: 100,
                color: Colors.white,
              ),
              SizedBox(height: 24),
              Text(
                'StockWatch',
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 16),
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
'@
            Set-Content -Path "lib\pages\splash_page.dart" -Value $splashContent -Encoding UTF8
            Write-Host "  ✓ Created splash_page.dart" -ForegroundColor Green
        }
    }
}

# Fix main.dart and stock_provider.dart (already done in previous script)
Write-Host "`n✓ main.dart and stock_provider.dart already fixed" -ForegroundColor Green

# Check final structure
Write-Host "`n📁 Final file structure:" -ForegroundColor Cyan
Get-ChildItem -Path "lib" -Recurse -File | ForEach-Object {
    Write-Host $_.FullName.Replace((Get-Location).Path + "\", "") -ForegroundColor Gray
}

# Run Flutter commands
Write-Host "`n🔧 Running Flutter commands..." -ForegroundColor Yellow
flutter clean
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs

Write-Host "`n✅ COMPLETE!" -ForegroundColor Green
Write-Host "`nRemaining tasks:" -ForegroundColor Yellow
Write-Host "1. Add google_logo.png to assets folder" -ForegroundColor White
Write-Host "2. Update API key in lib\services\api_service.dart" -ForegroundColor White
Write-Host "3. Run: flutter run" -ForegroundColor White