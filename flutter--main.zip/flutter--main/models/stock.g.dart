// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'stock.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Stock _$StockFromJson(Map<String, dynamic> json) => Stock(
      symbol: json['symbol'] as String,
      companyName: json['companyName'] as String,
      currentPrice: (json['currentPrice'] as num).toDouble(),
      priceChange: (json['priceChange'] as num).toDouble(),
      percentChange: (json['percentChange'] as num).toDouble(),
      previousClose: (json['previousClose'] as num).toDouble(),
      dayHigh: (json['dayHigh'] as num).toDouble(),
      dayLow: (json['dayLow'] as num).toDouble(),
      volume: (json['volume'] as num).toInt(),
      marketCap: (json['marketCap'] as num).toInt(),
      lastUpdate: DateTime.parse(json['lastUpdate'] as String),
    );

Map<String, dynamic> _$StockToJson(Stock instance) => <String, dynamic>{
      'symbol': instance.symbol,
      'companyName': instance.companyName,
      'currentPrice': instance.currentPrice,
      'priceChange': instance.priceChange,
      'percentChange': instance.percentChange,
      'previousClose': instance.previousClose,
      'dayHigh': instance.dayHigh,
      'dayLow': instance.dayLow,
      'volume': instance.volume,
      'marketCap': instance.marketCap,
      'lastUpdate': instance.lastUpdate.toIso8601String(),
    };
