class UserModel {
  final String? email;
  final String? displayName;
  final String? photoUrl;
  final String? uid;

  UserModel({
    this.email,
    this.displayName,
    this.photoUrl,
    this.uid,
  });

  factory UserModel.fromEmail(String email) {
    return UserModel(
      email: email,
      displayName: email.split('@')[0], // Use part before @ as display name
      photoUrl: null,
      uid: DateTime.now().millisecondsSinceEpoch.toString(),
    );
  }
}