class PortfolioHolding {
  final String symbol;
  final String name;
  final int shares;
  final double averagePrice;
  final double currentPrice;

  PortfolioHolding({
    required this.symbol,
    required this.name,
    required this.shares,
    required this.averagePrice,
    required this.currentPrice,
  });

  double get totalCost => averagePrice * shares;
  double get currentValue => currentPrice * shares;
  double get totalGainLoss => currentValue - totalCost;
  double get gainLossPercent => totalCost > 0 ? (totalGainLoss / totalCost) * 100 : 0.0;

  PortfolioHolding copyWith({
    String? symbol,
    String? name,
    int? shares,
    double? averagePrice,
    double? currentPrice,
  }) {
    return PortfolioHolding(
      symbol: symbol ?? this.symbol,
      name: name ?? this.name,
      shares: shares ?? this.shares,
      averagePrice: averagePrice ?? this.averagePrice,
      currentPrice: currentPrice ?? this.currentPrice,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'symbol': symbol,
      'name': name,
      'shares': shares,
      'averagePrice': averagePrice,
      'currentPrice': currentPrice,
    };
  }

  factory PortfolioHolding.fromJson(Map<String, dynamic> json) {
    return PortfolioHolding(
      symbol: json['symbol'],
      name: json['name'],
      shares: json['shares'],
      averagePrice: json['averagePrice'].toDouble(),
      currentPrice: json['currentPrice'].toDouble(),
    );
  }
}