class Stock {
  final String symbol;
  final String name;
  final double currentPrice;
  final double change;
  final double changePercent;
  final int volume;
  final int marketCap;

  Stock({
    required this.symbol,
    required this.name,
    required this.currentPrice,
    required this.change,
    required this.changePercent,
    required this.volume,
    required this.marketCap,
  });

  Stock copyWith({
    String? symbol,
    String? name,
    double? currentPrice,
    double? change,
    double? changePercent,
    int? volume,
    int? marketCap,
  }) {
    return Stock(
      symbol: symbol ?? this.symbol,
      name: name ?? this.name,
      currentPrice: currentPrice ?? this.currentPrice,
      change: change ?? this.change,
      changePercent: changePercent ?? this.changePercent,
      volume: volume ?? this.volume,
      marketCap: marketCap ?? this.marketCap,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'symbol': symbol,
      'name': name,
      'currentPrice': currentPrice,
      'change': change,
      'changePercent': changePercent,
      'volume': volume,
      'marketCap': marketCap,
    };
  }

  factory Stock.fromJson(Map<String, dynamic> json) {
    return Stock(
      symbol: json['symbol'],
      name: json['name'],
      currentPrice: json['currentPrice'].toDouble(),
      change: json['change'].toDouble(),
      changePercent: json['changePercent'].toDouble(),
      volume: json['volume'],
      marketCap: json['marketCap'],
    );
  }

  @override
  String toString() {
    return 'Stock(symbol: $symbol, name: $name, price: $currentPrice)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Stock && other.symbol == symbol;
  }

  @override
  int get hashCode => symbol.hashCode;
}