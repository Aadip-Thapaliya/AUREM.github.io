class User {
  final String id;
  final String email;
  final String displayName;
  final String? photoUrl;
  final List<String> watchlist;

  User({
    required this.id,
    required this.email,
    required this.displayName,
    this.photoUrl,
    required this.watchlist,
  });

  User copyWith({
    String? id,
    String? email,
    String? displayName,
    String? photoUrl,
    List<String>? watchlist,
  }) {
    return User(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      watchlist: watchlist ?? this.watchlist,
    );
  }
}