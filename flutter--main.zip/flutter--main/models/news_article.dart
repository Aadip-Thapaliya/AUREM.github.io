class NewsArticle {
  final String title;
  final String summary;
  final String url;
  final DateTime publishedAt;
  final String source;

  NewsArticle({
    required this.title,
    required this.summary,
    required this.url,
    required this.publishedAt,
    required this.source,
  });

  NewsArticle copyWith({
    String? title,
    String? summary,
    String? url,
    DateTime? publishedAt,
    String? source,
  }) {
    return NewsArticle(
      title: title ?? this.title,
      summary: summary ?? this.summary,
      url: url ?? this.url,
      publishedAt: publishedAt ?? this.publishedAt,
      source: source ?? this.source,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'summary': summary,
      'url': url,
      'publishedAt': publishedAt.toIso8601String(),
      'source': source,
    };
  }

  factory NewsArticle.fromJson(Map<String, dynamic> json) {
    return NewsArticle(
      title: json['title'],
      summary: json['summary'],
      url: json['url'],
      publishedAt: DateTime.parse(json['publishedAt']),
      source: json['source'],
    );
  }

  @override
  String toString() {
    return 'NewsArticle(title: $title, source: $source)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is NewsArticle && other.url == url;
  }

  @override
  int get hashCode => url.hashCode;
}