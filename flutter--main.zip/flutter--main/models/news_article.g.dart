// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'news_article.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NewsArticle _$NewsArticleFromJson(Map<String, dynamic> json) => NewsArticle(
      id: json['id'] as String,
      headline: json['headline'] as String,
      summary: json['summary'] as String,
      source: json['source'] as String,
      imageUrl: json['imageUrl'] as String,
      url: json['url'] as String,
      publishedAt: DateTime.parse(json['publishedAt'] as String),
      relatedStocks: (json['relatedStocks'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$NewsArticleToJson(NewsArticle instance) =>
    <String, dynamic>{
      'id': instance.id,
      'headline': instance.headline,
      'summary': instance.summary,
      'source': instance.source,
      'imageUrl': instance.imageUrl,
      'url': instance.url,
      'publishedAt': instance.publishedAt.toIso8601String(),
      'relatedStocks': instance.relatedStocks,
    };
