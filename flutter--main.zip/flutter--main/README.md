# StockWatch - Flutter Stock Market App

A complete, production-ready Flutter application for tracking stocks with real-time prices, charts, news, and Google Sign-In authentication.

## Setup Instructions

### 1. Create a New Flutter Project

```bash
flutter create stockwatch
cd stockwatch
```

### 2. Replace Files

1. Replace the `pubspec.yaml` file with the provided one
2. Delete the existing `lib` folder
3. Create a new `lib` folder with the following structure:

```
lib/
├── models/
│   ├── stock.dart
│   ├── news_article.dart
│   └── user.dart
├── services/
│   ├── api_service.dart
│   └── auth_service.dart
├── providers/
│   ├── auth_provider.dart
│   ├── stock_provider.dart
│   └── news_provider.dart
├── widgets/
│   ├── stock_list_item.dart
│   ├── news_card.dart
│   └── chart_widget.dart
├── pages/
│   ├── splash_page.dart
│   ├── login_page.dart
│   ├── home_page.dart
│   ├── stock_detail_page.dart
│   ├── watchlist_page.dart
│   └── settings_page.dart
└── main.dart
```

4. Copy each provided file into its corresponding location

### 3. Get Finnhub API Key

1. Go to [Finnhub.io](https://finnhub.io/)
2. Sign up for a free account
3. Get your API key
4. In `lib/services/api_service.dart`, replace `'YOUR_FINNHUB_API_KEY'` with your actual API key

### 4. Configure Firebase

1. Create a new Firebase project at [Firebase Console](https://console.firebase.google.com/)
2. Enable Google Sign-In:
    - Go to Authentication > Sign-in method
    - Enable Google provider

#### For Android:
1. Add your Android app to Firebase
2. Download `google-services.json`
3. Place it in `android/app/`
4. Add to `android/build.gradle`:
   ```gradle
   dependencies {
       classpath 'com.google.gms:google-services:4.3.15'
   }
   ```
5. Add to `android/app/build.gradle`:
   ```gradle
   apply plugin: 'com.google.gms.google-services'
   ```

#### For iOS:
1. Add your iOS app to Firebase
2. Download `GoogleService-Info.plist`
3. Add it to `ios/Runner/` using Xcode

### 5. Add Google Logo Asset

1. Create `assets` folder in project root
2. Add a Google logo image named `google_logo.png`
3. Update `pubspec.yaml`:
   ```yaml
   flutter:
     uses-material-design: true
     assets:
       - assets/google_logo.png
   ```

### 6. Generate Code

```bash
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
```

### 7. Run the App

```bash
flutter run
```

## Features

- **Google Sign-In Authentication**
- **Real-time Stock Prices** via WebSocket
- **Interactive Price Charts** with multiple time periods
- **Latest Financial News**
- **Watchlist Management** with persistent storage
- **Buy/Sell Simulation**
- **User Settings & Profile**
- **Dark Mode Support** (UI ready)

## API Integration

The app uses Finnhub.io API for:
- Real-time stock quotes
- Historical price data
- Market news
- Company news

## State Management

Uses Provider pattern for:
- Authentication state
- Stock data management
- News feed
- User preferences

## Error Handling

- Comprehensive error states
- Retry mechanisms
- Offline support for watchlist

## Notes

- The buy/sell feature is simulation only
- WebSocket connection provides real-time updates
- All data is cached for performance
- Watchlist persists locally using SharedPreferences