import 'package:flutter/foundation.dart';
import 'dart:io';
import '../models/user_model.dart';

class AuthService {
  static bool get isFirebaseSupported =>
      !kIsWeb && (Platform.isAndroid || Platform.isIOS);

  /// Sign in with Google
  /// Returns UserModel on success, null on failure
  static Future<UserModel?> signInWithGoogle() async {
    try {
      if (!isFirebaseSupported) {
        // Mock authentication for Windows/Web
        await Future.delayed(const Duration(seconds: 1));
        return UserModel(
          email: "demo@example.com",
          displayName: "Demo User",
          photoUrl: null,
          uid: "demo_${DateTime.now().millisecondsSinceEpoch}",
        );
      } else {
        // TODO: Real Firebase authentication when configured
        // For now, return mock data for mobile too
        await Future.delayed(const Duration(seconds: 2));
        return UserModel(
          email: "mobile@example.com",
          displayName: "Mobile User",
          photoUrl: "https://via.placeholder.com/150",
          uid: "mobile_${DateTime.now().millisecondsSinceEpoch}",
        );

        /* When you configure Firebase, replace above with:

        import 'package:firebase_auth/firebase_auth.dart';
        import 'package:google_sign_in/google_sign_in.dart';

        final GoogleSignIn googleSignIn = GoogleSignIn();
        final GoogleSignInAccount? googleUser = await googleSignIn.signIn();

        if (googleUser == null) {
          // User canceled the sign-in
          return null;
        }

        final GoogleSignInAuthentication googleAuth =
            await googleUser.authentication;

        final credential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );

        final UserCredential userCredential =
            await FirebaseAuth.instance.signInWithCredential(credential);

        final User? firebaseUser = userCredential.user;
        if (firebaseUser != null) {
          return UserModel(
            email: firebaseUser.email,
            displayName: firebaseUser.displayName ?? firebaseUser.email?.split('@')[0],
            photoUrl: firebaseUser.photoURL,
            uid: firebaseUser.uid,
          );
        }

        return null;
        */
      }
    } catch (e) {
      debugPrint('AuthService.signInWithGoogle error: $e');
      return null;
    }
  }

  /// Sign out user
  static Future<bool> signOut() async {
    try {
      if (isFirebaseSupported) {
        // TODO: When Firebase is configured, uncomment:
        // await FirebaseAuth.instance.signOut();
        // await GoogleSignIn().signOut();
      }

      // For now, just simulate sign out
      await Future.delayed(const Duration(milliseconds: 500));
      return true;
    } catch (e) {
      debugPrint('AuthService.signOut error: $e');
      return false;
    }
  }

  /// Get current user from Firebase (when configured)
  static UserModel? getCurrentUser() {
    if (!isFirebaseSupported) {
      return null;
    }

    // TODO: When Firebase is configured, replace with:
    // final User? firebaseUser = FirebaseAuth.instance.currentUser;
    // if (firebaseUser != null) {
    //   return UserModel(
    //     email: firebaseUser.email,
    //     displayName: firebaseUser.displayName ?? firebaseUser.email?.split('@')[0],
    //     photoUrl: firebaseUser.photoURL,
    //     uid: firebaseUser.uid,
    //   );
    // }

    return null;
  }

  /// Listen to authentication state changes (for Firebase)
  static Stream<UserModel?> get authStateChanges {
    if (!isFirebaseSupported) {
      // Return empty stream for unsupported platforms
      return Stream.empty();
    }

    // TODO: When Firebase is configured, replace with:
    // return FirebaseAuth.instance.authStateChanges().map((User? user) {
    //   if (user != null) {
    //     return UserModel(
    //       email: user.email,
    //       displayName: user.displayName ?? user.email?.split('@')[0],
    //       photoUrl: user.photoURL,
    //       uid: user.uid,
    //     );
    //   }
    //   return null;
    // });

    // For now, return empty stream
    return Stream.empty();
  }

  /// Check if user is currently signed in
  static bool isSignedIn() {
    if (!isFirebaseSupported) {
      return false;
    }

    // TODO: When Firebase is configured, replace with:
    // return FirebaseAuth.instance.currentUser != null;

    return false;
  }
}